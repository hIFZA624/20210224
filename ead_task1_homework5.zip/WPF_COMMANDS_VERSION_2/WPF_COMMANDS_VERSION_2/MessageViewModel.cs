﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace WPF_COMMANDS_VERSION_2
{
    class MessageViewModel
    {
        public  string username { get; set; }
        public string oldPassword { get; set; }
        public string newPassword { get; set; }
        public string confirmPassword { get; set; }

        public MsgCommand cmd { get; set; }
        public  MessageViewModel()
        {
            cmd = new MsgCommand(this);
        }
       public  bool canexecute()
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(oldPassword) || string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
                return false;
            else
                return true;
        }

    }
}
