﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using System.Windows;
namespace WPF_COMMANDS_VERSION_2
{
    class MsgCommand : ICommand
    {
        public event EventHandler CanExecuteChanged
        {
            add
            {
                CommandManager.RequerySuggested += value;
            }
            remove
            {
                CommandManager.RequerySuggested -= value;
            }
        }
        private MessageViewModel vm;
      public  MsgCommand(MessageViewModel msgmv)
        {
            vm = msgmv;
        }

        public bool CanExecute(object parameter)
        {
            return vm.canexecute();
        }

        public void Execute(object parameter)
        {
           if(vm.newPassword==vm.confirmPassword)
            {
                MessageBox.Show("Password changed succesfully");
            }
           else
                MessageBox.Show("Your confirmation was invalid");
        }
    }
}
