﻿namespace Business_Logic_Layer
{
    internal class dal
    {
        public dal()
        {
        }
    }
}