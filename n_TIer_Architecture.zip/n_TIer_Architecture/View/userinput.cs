﻿using System;
using System.Collections.Generic;
using System.Text;

namespace View
{
    class userinput
    {
       public userinput()
        {
            Console.WriteLine("enter string");
            string input = Console.ReadLine();

        }
    }
}
