﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
namespace SimpleBlogApplication.Models
{
    public   class PostRepository
    {
        public LinkedList<UserPost> userPosts = new LinkedList<UserPost>();
        public List<addUser> addUsers = new List<addUser>();
        //public List<string> currentUser = new List<string>();
        string connString = null;
        SqlConnection con;
        public PostRepository()
        {
            connString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=PostInfo;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            con = new SqlConnection(connString);
            con.Open();
            string query = "Select * from Posts";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                UserPost pro = new UserPost();
                pro.Id =System.Convert.ToInt32(dr.GetValue(0));
                pro.userName = dr.GetValue(1).ToString();
                pro.Title = dr.GetValue(2).ToString();
                pro.Post = dr.GetValue(3).ToString();
                pro.Date =dr.GetValue(4).ToString();
                pro.PhotoPath = dr.GetValue(5).ToString();
                userPosts.AddFirst(pro);
            }
            con.Close();
            con.Open();
            string query1 = "Select * from UserInfo";
            SqlCommand cmd1= new SqlCommand(query1, con);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                addUser add = new addUser();
                add.Email = dr1.GetValue(0).ToString();
                add.userName = dr1.GetValue(1).ToString();
                add.OldPassword= dr1.GetValue(2).ToString();
               add.PhotoPath = dr1.GetValue(4).ToString();
                add.Id = System.Convert.ToInt32(dr1.GetValue(3));
                // pro.Date = dr.GetValue(4).ToString();
                // pro.PhotoPath = dr.GetValue(5).ToString();
                addUsers.Add(add);
            }
            con.Close();
        }
        public void addPost(UserPost p)
        {
            string activeUser = null;
            string photoPath = null;
             con.Open();
             string query1 = "Select * from Active";
             SqlCommand cmd1 = new SqlCommand(query1, con);
             SqlDataReader dr1 = cmd1.ExecuteReader();
             while (dr1.Read())
             {
                 activeUser = dr1.GetValue(1).ToString();
             }
             con.Close();
            //string path = "C:\Users\mehro\OneDrive\Documents\ProfilePic.jpg";
            con.Open();
            string query2 = "Select * from UserInfo";
            SqlCommand cmd2 = new SqlCommand(query2, con);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                if(activeUser==dr2.GetValue(1).ToString())
                      photoPath = dr2.GetValue(4).ToString();
            }
            con.Close();
            DateTime dateAndTime = DateTime.Now;
            string date=dateAndTime.ToString("dd/MM/yyyy");
            p.userName = activeUser;
            p.Date = date;
            p.PhotoPath = photoPath;
           
            con.Open();
            string query = $"insert into Posts(UserName,Title,Post,Date,Picture) values('{activeUser}','{p.Title}','{p.Post}','{date}','{photoPath}')";
            SqlCommand cmd = new SqlCommand(query, con);
            int no = cmd.ExecuteNonQuery();
            con.Close();
            con.Open();
            string query3 = "Select * from Posts";
            SqlCommand cmd3 = new SqlCommand(query3, con);
            SqlDataReader dr3 = cmd3.ExecuteReader();
            int id = 0;
            while (dr3.Read())
            {   
                id = System.Convert.ToInt32(dr3.GetValue(0));
            }
            con.Close();
            p.Id = id;
            userPosts.AddFirst(p);
            //p.date = DateTime.UtcNow.Date;
        }
        public void addUser(string email ,string username,string psw)
        {
            string path = "ProfilePicture.png";
            con.Open();
            string query = $"insert into UserInfo(Email,UserName,Password,PhotoPath) values('{email}','{username}','{psw}','{path}')";
            SqlCommand cmd = new SqlCommand(query, con);
            int no = cmd.ExecuteNonQuery();
            con.Close();
            addUser user = new addUser();
            user.Email = email;
            user.OldPassword = psw;
            user.userName = username;
            user.PhotoPath = path;
            con.Open();
            string query3 = "Select * from UserInfo";
            SqlCommand cmd3 = new SqlCommand(query3, con);
            SqlDataReader dr3 = cmd3.ExecuteReader();
            int id = 0;
            while (dr3.Read())
            {
                id = System.Convert.ToInt32(dr3.GetValue(3));
            }
            con.Close();
            user.Id = id;
            addUsers.Add(user);
        }
        public bool checkLogin(string username,string password)
        {
            con.Open();
            string query = "Select * from UserInfo";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                string user = dr.GetValue(1).ToString();
                string pass = dr.GetValue(2).ToString();
                if (user==username && pass==password)
                {
                    con.Close();
                     con.Open();
                     string query1 = $"insert into Active(ActiveUser) values('{username}')";
                     SqlCommand cmd1 = new SqlCommand(query1, con);
                     int no = cmd1.ExecuteNonQuery();
                   // currentUser.Add(username);
                    con.Close();
                    return true;
                }
            }
            con.Close();
            return false;
        }
        public void updateUser(string userName,string email,string oldPassword,string newPassword,string photoPath)
        {
            string activeUser = null;
            con.Open();
             string query1 = "Select * from Active";
             SqlCommand cmd1 = new SqlCommand(query1, con);
             SqlDataReader dr1 = cmd1.ExecuteReader();
             while (dr1.Read())
             {
                 activeUser = dr1.GetValue(1).ToString();
             }
             con.Close();
           // activeUser = "Shazia";
            con.Open();
            string query = null;
            if(string.IsNullOrEmpty( photoPath) && string.IsNullOrEmpty(newPassword))
                query = $"Update UserInfo set UserName='{userName}',Email='{email}' where UserName='{activeUser}' ";
            if (string.IsNullOrEmpty(photoPath)==false && string.IsNullOrEmpty(newPassword)==true)
                query = $"Update UserInfo set UserName='{userName}',Email='{email}',PhotoPath='{photoPath}' where UserName='{activeUser}'";
            if (string.IsNullOrEmpty(photoPath)==true && string.IsNullOrEmpty(newPassword)==false)
                query = $"Update UserInfo set UserName='{userName}',Email='{email}',Password='{newPassword}' where UserName='{activeUser}' ";
            SqlCommand cmd = new SqlCommand(query, con);
            int insertedRows = cmd.ExecuteNonQuery();
            con.Close();
            if (string.IsNullOrEmpty(photoPath)==false)
            {
                con.Open();
                string query2 = $"Update Posts set Picture='{photoPath}' where UserName='{activeUser}'";
                SqlCommand cmd2 = new SqlCommand(query2, con);
                int no = cmd2.ExecuteNonQuery();
                con.Close();  
            }
            if(userName!=activeUser)
            {
                con.Open();
                string query2 = $"Update Posts set UserName='{userName}' where UserName='{activeUser}'";
                SqlCommand cmd2 = new SqlCommand(query2, con);
                int no = cmd2.ExecuteNonQuery();
                con.Close();
                con.Open();
                string query3 = $"Update Active set ActiveUser='{userName}'";
                SqlCommand cmd3 = new SqlCommand(query3, con);
                int no1 = cmd3.ExecuteNonQuery();
                con.Close();
            }
            foreach (UserPost u in userPosts)
            {
                if (activeUser==u.userName && string.IsNullOrEmpty(userName)==false)
                {
                    u.userName = userName;
                }
                if ((u.userName == userName || activeUser == u.userName) && (string.IsNullOrEmpty(photoPath) == false))
                {
                    u.PhotoPath = photoPath;
                }
            }
        }
        public addUser activeUser()
        {
            string activeUser = null;
            con.Open();
            string query1 = "Select * from Active";
            SqlCommand cmd1 = new SqlCommand(query1, con);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                activeUser = dr1.GetValue(1).ToString();
            }
            con.Close();
            con.Open();
            string query = "Select * from UserInfo";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                if (activeUser == dr.GetValue(1).ToString())
                {
                    addUser pro = new addUser();
                    pro.Email = dr.GetValue(0).ToString();
                    pro.userName = dr.GetValue(1).ToString();
                    pro.OldPassword = dr.GetValue(2).ToString();
                    pro.PhotoPath = dr.GetValue(4).ToString();
                  
                    con.Close();
                    return pro;
                }
            }
            con.Close();
            addUser pro1 = new addUser();
            
            return pro1;
        }
        public void logout()
        {
            con.Open();
            string query1 = "Delete from Active";
            SqlCommand cmd1 = new SqlCommand(query1, con);
            int no = cmd1.ExecuteNonQuery();
            con.Close();
        }
        public void editPost(UserPost post)
        {
            con.Open();
            string query = null;
            query = $"Update Posts set Title='{post.Title}',Post='{post.Post}' where  Id='{post.Id}' ";
            SqlCommand cmd = new SqlCommand(query, con);
            int insertedRows = cmd.ExecuteNonQuery();
            con.Close();
            foreach (UserPost u in userPosts)
            {
                if (post.Id==u.Id)
                {
                    u.Title = post.Title;
                    u.Post = post.Post;
                }
            }
        }
        public void delete(int id)
        {
            con.Open();
            string query = null;
            query = $"Delete from Posts  where  Id='{id}' ";
            SqlCommand cmd = new SqlCommand(query, con);
            int insertedRows = cmd.ExecuteNonQuery();
            con.Close();
            UserPost user = new UserPost();
            foreach (UserPost userPost in userPosts)
            {
               
                if (id == userPost.Id)
                {
                    userPosts.Remove(userPost);
                    break;
                  /*  user.Id = userPost.Id;
                    user.Title = userPost.Title;
                    user.Post = userPost.Post;
                    user.Date = userPost.Date;
                    user.userName = userPost.userName;
                    user.PhotoPath = userPost.PhotoPath;
                    break;
                    */
                    
                }
            }
           // userPosts.Remove(user);
        }
        public void removeUser(addUser del)
        {
            con.Open();
            string query1 = $"Delete from UserInfo where UserName='{del.userName}'";
            SqlCommand cmd1 = new SqlCommand(query1, con);
            int no = cmd1.ExecuteNonQuery();
            con.Close();
            addUsers.Remove(del);
        }
        public void editUser(addUser edit)
        {
            con.Open();
            string query1 = $"Update  UserInfo set UserName='{edit.userName}',Email='{edit.Email}',Password='{edit.OldPassword}' where Id='{edit.Id}'";
            SqlCommand cmd1 = new SqlCommand(query1, con);
            int no = cmd1.ExecuteNonQuery();
            con.Close();
            foreach (addUser u in addUsers)
            {
                if (edit.Id == u.Id)
                {
                    u.userName = edit.userName;
                    u.OldPassword = edit.OldPassword;
                    u.Email = edit.Email;

                }
            }
            //addUsers.Remove(del);
        }
    }
}
