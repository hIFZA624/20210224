﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace SimpleBlogApplication.Models
{
    public class addUser
    {
        public  int Id { get; set; }
        public string userName { get; set; }
        public string Email { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }
        public IFormFile Photo { get; set; }
        public string PhotoPath { get; set; }

    }
}
