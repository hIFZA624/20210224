﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using SimpleBlogApplication.Models;
namespace SimpleBlogApplication.Controllers
{
    public class RegularController : Controller
    {
        
        PostRepository postList = new PostRepository();
        private readonly IHostingEnvironment hostingEnvironment;
        public RegularController(IHostingEnvironment hostingEnvironment)
        {
            this.hostingEnvironment = hostingEnvironment;
        }
       
        [HttpGet]
        public ViewResult Login()
        {
            return View();
        }
        [HttpPost]
        public ViewResult Login(string usr,string psw)
        {
           bool result= postList.checkLogin(usr, psw);
            if (result == true)
                return View("RegularUserView", postList.userPosts);
            else
                return View("LoginError");
        }
       [HttpGet]
        public ViewResult SignUp()
        {
            return View();
        }
       [HttpPost]
       public ViewResult SignUp(string email,string usr,string psw)
        {
            postList.addUser(email,usr,psw);
            return View("Login");
        }
        
        public ViewResult RegularUserView()
        {
            return View(postList.userPosts);
        }
        [HttpGet]
        public ViewResult CreatePost()
        {
            return View();
        }
        [HttpPost]
        public ViewResult CreatePost(string title,string post)
        {
            UserPost p = new UserPost();
            p.Title = title;
            p.Post = post;
            postList.addPost(p);
            return View("RegularUserView", postList.userPosts);
        }
        [HttpGet]
        public ViewResult UserProfile()
        {
            addUser add = postList.activeUser();
            return View(add);
        }
        [HttpPost]
        public ViewResult UserProfile(addUser user)
        {
            string uniqueFileName = null;
            if (user.Photo!=null)
            {
              string uploadsFolder= Path.Combine( hostingEnvironment.WebRootPath, "images");
                uniqueFileName=Guid.NewGuid().ToString() + "_" + user.Photo.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                user.Photo.CopyTo(new FileStream(filePath, FileMode.Create));
            }
            postList.updateUser(user.userName, user.Email, user.OldPassword, user.NewPassword, uniqueFileName);
           
            return View("RegularUserView", postList.userPosts);
        }
        /*[HttpGet]
        public ViewResult PostView(int id)
        {
          UserPost user = new UserPost();
          foreach(UserPost userPost in postList.userPosts)
            {
                if(id==userPost.Id)
                {
                    user.Id = userPost.Id;
                    user.Title = userPost.Title;
                    user.Post = userPost.Post;
                    user.Date = userPost.Date;
                    user.userName = userPost.userName;
                    user.PhotoPath = userPost.PhotoPath;
                }
            }
            return View(user);
        }
        */
        [HttpGet]
        public ViewResult PostView(int id)
        {
            UserPost user = new UserPost();
            addUser check = postList.activeUser();
          foreach(UserPost userPost in postList.userPosts)
            {
                if(id==userPost.Id)
                {
                    user.Id = userPost.Id;
                    user.Title = userPost.Title;
                    user.Post = userPost.Post;
                    user.Date = userPost.Date;
                    user.userName = userPost.userName;
                    user.PhotoPath = userPost.PhotoPath;
                }
            }
            user.userName = user.userName;
            check.userName = check.userName;
            if (user.userName == check.userName)
                return View("PostView", user);
            else
                return View("PostViewOnly", user);      
        }
        [HttpPost]
        public ViewResult PostView()
        {
            return View();
        }
        [HttpGet]
        public ViewResult EditPost(int id)
        {
            UserPost user = new UserPost();
            foreach (UserPost userPost in postList.userPosts)
            {
                if (id == userPost.Id)
                {
            
                    user.Title = userPost.Title;
                    user.Post = userPost.Post; 
                }
            }
            return View(user);
        }
        [HttpPost]
        public ViewResult EditPost(UserPost userPost)
        {
            UserPost p = new UserPost();
            p.Id = userPost.Id;
            p.Title = userPost.Title;
            p.Post = userPost.Post;
            postList.editPost(p);
            return View("RegularUserView", postList.userPosts);
        }
        public ViewResult Logout()
        {
            postList.logout();
            return View("Login");
        }
        public ViewResult Delete(int id)
        {
            postList.delete(id);
            return View("RegularUserView", postList.userPosts);
        }
    }
}
 