﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SimpleBlogApplication.Models;

namespace SimpleBlogApplication.Controllers
{
    public class AdminController : Controller
    {
        PostRepository postList = new PostRepository();
        public ViewResult Details(int id)
        {
           addUser user = new addUser();
            foreach (addUser add in postList.addUsers)
            {
                if (id == add.Id)
                {
                    user.PhotoPath = add.PhotoPath;
                    user.Email = add.Email;
                    user.userName = add.userName;
                    user.OldPassword = add.OldPassword;
                }
            }
            return View(user);
        }
        public ViewResult Remove(int id)
        {
            addUser user = postList.addUsers.Find(user => user.Id == id);
            postList.removeUser(user);
            return View("Home", postList.addUsers);
        }
        [HttpGet]
        public ViewResult AddUser()
        {
            return View();
        }
        [HttpPost]
        public ViewResult AddUser(string username, string email, string password)
        {
            postList.addUser(email, username, password);
            return View("Home", postList.addUsers);
        }
        [HttpGet]
        public ViewResult Edit(int id)
        {
            addUser user = postList.addUsers.Find(user => user.Id == id);
            return View("EditUser", user);
        }
        [HttpPost]
        public ViewResult Edit(addUser user)
        {
            postList.editUser(user);
            return View("Home", postList.addUsers);
        }
        public ViewResult Home()
        {
            return View(postList.addUsers);
        }
    }
}